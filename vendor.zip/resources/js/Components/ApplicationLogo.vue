<template>
    <img :src="logo" class="w-48" alt="">
</template>

<script setup>
import logo from "./../../img/1.png"

</script>
