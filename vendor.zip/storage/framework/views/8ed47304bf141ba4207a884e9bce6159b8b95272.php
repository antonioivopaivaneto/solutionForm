<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <h1>Nova Solicitacao</h1>
    <br>
<hr>

<b>Condominio:</b> <span><?php echo e($solicitacao->condominio); ?></span><br>
<b>Unidade:</b> <span><?php echo e($solicitacao->unidade); ?></span><br>
<b>Morador:</b> <span><?php echo e($solicitacao->nome); ?></span><br>
<b>Assunto:</b> <span><?php echo e($solicitacao->assunto); ?></span><br>
<b>Solicitacao:</b> <span><?php echo e($solicitacao->solicitacao); ?></span><br>
<b>Email para Retorno:</b> <span><?php echo e($solicitacao->email); ?></span><br>

<?php if($solicitacao->foto): ?>
<img src="<?php echo e(url( $solicitacao->foto)); ?>" alt="Image" width="200"/>
<?php else: ?>
<p>Nenhuma foto disponível</p>
<?php endif; ?>


</body>
</html>
<?php /**PATH C:\laragon\www\solutionForm\resources\views/mail/solicitacao.blade.php ENDPATH**/ ?>